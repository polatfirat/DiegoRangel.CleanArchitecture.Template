﻿using $ext_safeprojectname$.Domain.Example;
using $ext_safeprojectname$.Domain.Example.Repositories;
using $safeprojectname$.Contexts;
using DiegoRangel.DotNet.Framework.CQRS.Infra.Data.EFCore.Repositories;

namespace $safeprojectname$.Repositories
{
    public class ExampleRepository : CrudRepository<Example>, IExampleRepository
    {
        public ExampleRepository(AppDbContext context) : base(context)
        {
        }
    }
}