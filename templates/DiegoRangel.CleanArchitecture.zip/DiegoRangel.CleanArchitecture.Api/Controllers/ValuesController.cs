﻿using System.Threading.Tasks;
using $safeprojectname$.ViewModels.Examples;
using $ext_safeprojectname$.Domain.Example.Commands;
using DiegoRangel.DotNet.Framework.CQRS.API.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    [Route("api/values")]
    public class ValuesController : ApiControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> GenerateKey()
        {
            var result = await Mediator.Send(new GenerateKeyCommand());
            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddExample([FromBody] CreateExampleCommand input)
        {
            var result = await Mediator.Send(input);
            return Ok(Mapper.Map<ExampleViewModel>(result));
        }
    }
}