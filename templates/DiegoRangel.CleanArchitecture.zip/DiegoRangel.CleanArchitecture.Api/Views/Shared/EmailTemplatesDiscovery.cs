﻿namespace $safeprojectname$.Views.Shared
{
    /// <summary>
    /// It's just an empty class used to recognize the email templating files.
    /// </summary>
    public class EmailTemplatesDiscovery
    {
        
    }
}