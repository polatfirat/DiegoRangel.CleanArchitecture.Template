﻿using $ext_safeprojectname$.Domain.Example;
using DiegoRangel.DotNet.Framework.CQRS.API.Mapper;

namespace $safeprojectname$.ViewModels.Examples
{
    public class ExampleViewModel : IViewModel<Example>
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}