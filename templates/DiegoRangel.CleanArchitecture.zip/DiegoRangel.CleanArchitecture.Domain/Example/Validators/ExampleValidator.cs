﻿using FluentValidation;

namespace $safeprojectname$.Example.Validators
{
    public class ExampleValidator : AbstractValidator<Example>
    {
        public ExampleValidator()
        {
            RuleFor(x => x.Title).NotEmpty();
        }
    }
}