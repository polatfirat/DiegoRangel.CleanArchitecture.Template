﻿using DiegoRangel.DotNet.Framework.CQRS.Domain.Core.Interfaces;

namespace $safeprojectname$.Common.UoW
{
    public interface IApplicationUnitOfWork : IUnitOfWork
    {
        
    }
}