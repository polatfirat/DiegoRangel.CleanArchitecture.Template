﻿namespace $safeprojectname$.Common
{
    /// <summary>
    /// It's just an empty class used to reference this Project's assembly.
    /// </summary>
    public class ProjectIdentifier
    {
        
    }
}