﻿using $ext_safeprojectname$.Infra.DataAccess.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public static class IocManager
    {
        public static void RegisterApplicationServices(IServiceCollection services)
        {
            services.AddDbContext<AppDbContext>(options => options.UseInMemoryDatabase("MyInMemoryDatabase"));
        }
    }
}