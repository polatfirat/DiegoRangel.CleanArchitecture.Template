﻿namespace $safeprojectname$.Settings
{
    public class AppSettings
    {
        public string ProductName { get; set; }
        public string ProductDisplayName { get; set; }
        public string FrontEndUrl { get; set; }
    }
}